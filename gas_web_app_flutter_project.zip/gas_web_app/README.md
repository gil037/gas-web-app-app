# Gas Web App - Flutter Android APK

Aplikasi Android Flutter WebView untuk Google Apps Script (GAS) Web App:
`https://script.google.com/macros/s/AKfycbyEgh0HFbt-fytb84YBv_cyHFl4j9WdjhhF-C4dfn6TX2ZFXr9PoxxhM7VO2m4kmq0H9w/exec`

---

## 🚀 3 Cara Membangun APK (Build APK)

### Cara 1: Otomatis via GitHub Actions (PALING MUDAH - Tanpa Install Flutter!)
1. Buat repository baru di **GitHub** (gratis).
2. Upload seluruh isi folder project ini ke repository tersebut.
3. Buka tab **Actions** di GitHub Anda.
4. Workflow **"Build Release APK"** akan otomatis berjalan dalam ~2 menit.
5. Selesai! Klik build yang berhasil dan download file **`gasapp-release-apk.zip`** yang berisi file **`app-release.apk`**.

---

### Cara 2: Build di Komputer Sendiri (Flutter CLI)
Jika Anda sudah menginstal Flutter SDK & Android Studio:

```bash
# 1. Buka terminal di folder ini
cd gasapp

# 2. Download package yang dibutuhkan
flutter pub get

# 3. Build APK versi release
flutter build apk --release
```

File APK akan tersedia di lokasi:
📂 `build/app/outputs/flutter-apk/app-release.apk`

Tinggal kirim file `app-release.apk` ini ke HP Android Anda lewat WhatsApp, Telegram, Google Drive, atau kabel USB, lalu klik Install!

---

### Cara 3: Lewat Android Studio / VS Code
1. Buka Android Studio atau VS Code.
2. Pilih **Open Folder** -> pilih folder project ini.
3. Colokkan HP Android dengan fitur **USB Debugging** aktif.
4. Klik tombol **Run** (F5) untuk mengetes langsung di HP.
5. Untuk membuat APK: di menu Android Studio pilih **Build** > **Flutter** > **Build APK**.

---

## ⚙️ Fitur yang Diterapkan:
- **Google Apps Script Web App Direct Load**: Menjalankan URL GAS dengan JavaScript mode unrestricted.
- **Smart Back Button**: Menekan tombol Back di HP akan mundur ke halaman sebelumnya di web, bukan langsung menutup aplikasi.
- **Google Login User-Agent Fix**: Mengatasi error *"This browser or app may not be secure"* saat login akun Google di WebView.
- **Pull-To-Refresh**: Tarik ke bawah untuk reload data form.
- **Offline Error Handling**: Tampilan ramah dengan tombol "Coba Lagi" jika sinyal hilang.
- **Izin Lengkap**: Internet, Camera, & Storage di `AndroidManifest.xml` untuk upload file di formulir GAS.

---

## 📝 Catatan Penting untuk Google Apps Script
Pastikan Web App Google Apps Script Anda telah di-*Deploy* dengan pengaturan:
- **Execute as**: *Me (email Anda)*
- **Who has access**: *Anyone* (Siapa saja)
