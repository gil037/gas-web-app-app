@echo off
echo =============================================
echo  Building APK for Gas Web App...
echo =============================================

where flutter >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Flutter is not installed or not in PATH!
    echo Download from https://flutter.dev
    pause
    exit /b 1
)

echo 1. Getting dependencies...
call flutter pub get

echo 2. Building Release APK...
call flutter build apk --release

echo =============================================
echo  SUCCESS! Your APK is ready:
echo  build\app\outputs\flutter-apk\app-release.apk
echo =============================================
pause
