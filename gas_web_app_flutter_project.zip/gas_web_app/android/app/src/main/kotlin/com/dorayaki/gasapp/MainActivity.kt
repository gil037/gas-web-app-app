package com.dorayaki.gasapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
