#!/usr/bin/env bash
# Quick script to build the Flutter APK locally
set -e

echo "============================================="
echo " Building APK for Gas Web App..."
echo "============================================="

# 1. Check flutter installed
if ! command -v flutter &> /dev/null
then
    echo "ERROR: Flutter command not found. Please install Flutter SDK from https://flutter.dev"
    exit 1
fi

echo "1. Getting Flutter dependencies..."
flutter pub get

echo "2. Building release APK..."
flutter build apk --release

echo ""
echo "============================================="
echo " SUCCESS! APK Build Completed:"
echo " build/app/outputs/flutter-apk/app-release.apk"
echo "============================================="
